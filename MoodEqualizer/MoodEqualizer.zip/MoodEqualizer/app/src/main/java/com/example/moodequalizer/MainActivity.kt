package com.example.moodequalizer

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fileOpen.setOnClickListener{
            val intent = Intent (this, fileOpenActivity::class.java)
            startActivity(intent)
        }
        filePlay.setOnClickListener{
            val intent = Intent(this, filePlayActivity::class.java)
            startActivity(intent)
        }
    }
}
